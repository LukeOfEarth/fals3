'use strict';

// Load the native .node addon built by NAPI-RS.
// When installed from NPM the binary is pre-built; during local dev it is
// compiled by `napi build` or `cargo build` and placed in the package dir.

const { existsSync } = require('fs');
const { join } = require('path');

function loadAddon() {
  // 1. Try a pre-built binary placed next to this file (npm publish layout).
  // Accept either the new (fals3y.node) or legacy (fals3.node) filename so
  // mid-rename installs keep working.
  for (const fname of ['fals3y.node', 'fals3.node']) {
    const p = join(__dirname, fname);
    if (existsSync(p)) {
      return require(p);
    }
  }

  // 2. Try the Cargo build output directly (local development).  Cargo names
  // the cdylib `libfals3_node.{dylib,so}` / `fals3_node.dll` regardless of
  // npm package name — the rust crate is still `fals3-node`.
  for (const profile of ['debug', 'release']) {
    const candidates = [
      join(__dirname, '..', 'target', profile, 'libfals3_node.dylib'),
      join(__dirname, '..', 'target', profile, 'libfals3_node.so'),
      join(__dirname, '..', 'target', profile, 'fals3_node.dll'),
    ];
    for (const p of candidates) {
      if (existsSync(p)) {
        return require(p);
      }
    }
  }

  throw new Error(
    'fals3y: could not find native addon. ' +
    'Run `npm run build:native` in the npm/ directory, ' +
    'or `cargo build -p fals3-node --release` from the repo root.'
  );
}

module.exports = loadAddon();
